package com.example.pokemon

import android.app.Instrumentation
import android.companion.DeviceId
import android.health.connect.datatypes.Device
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class Prueba {

    private lateinit var device : UiDevice

    @Before
    fun setup(){

        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())


        var context = InstrumentationRegistry.getInstrumentation().targetContext

        var packageName = context.packageName


        var command = "monkey -p $packageName -c android.intent.category.LAUNCHER 1"

        InstrumentationRegistry.getInstrumentation().uiAutomation.executeShellCommand(command)

        device.wait(Until.hasObject(By.pkg(packageName).depth(0)), 5000)



    }

    @Test
    fun validarCampos(){


        device.wait(Until.hasObject(By.res("com.example.pokemon:id/etPokemonNombre")), 5000)

        var linkRegistro = device.findObject(By.res("com.example.pokemon:id/etPokemonNombre"))

        checkNotNull(linkRegistro) {"No se encontro el campo para registrar"}

        linkRegistro.click()

        Thread.sleep(1000)

        linkRegistro.setText("charizard")

        Thread.sleep(1000)

        device.pressEnter()

        Thread.sleep(1000)


        //Boton

        device.wait(Until.hasObject(By.res("com.example.pokemon:id/btnBuscar")), 5000)

        var linkBoton = device.findObject(By.res("com.example.pokemon:id/btnBuscar"))

        checkNotNull(linkBoton) {"No se encontro el campo boton"}

        linkBoton.click()

        Thread.sleep(1000)

        Thread.sleep(1000)

        device.pressEnter()

        Thread.sleep(1000)


    }
}