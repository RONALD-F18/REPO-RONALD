package com.example.pokemon

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var etPokemonNombre: TextInputEditText
    private lateinit var btnBuscar: Button
    private lateinit var ivPokemon: ImageView
    private lateinit var tvNombre: TextView
    private lateinit var tvTipo: TextView
    private lateinit var tvHabilidades: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        etPokemonNombre = findViewById(R.id.etPokemonNombre)
        btnBuscar = findViewById(R.id.btnBuscar)
        ivPokemon = findViewById(R.id.ivPokemon)
        tvNombre = findViewById(R.id.tvNombre)
        tvTipo = findViewById(R.id.tvTipo)
        tvHabilidades = findViewById(R.id.tvHabilidades)

        btnBuscar.setOnClickListener {

            var nombre = etPokemonNombre.text.toString().trim().lowercase()

            if (nombre.isEmpty()) {
                Toast.makeText(this, "Escribe un nombre", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            var url = "https://pokeapi.co/api/v2/pokemon/$nombre"

            var queue = Volley.newRequestQueue(this)

            var stringRequest = StringRequest(
                Request.Method.GET,
                url,
                { response ->
                    try {
                        val jsonObject = JSONObject(response)

                        // Nombre
                        var name = jsonObject.optString("name", "Sin nombre")
                        tvNombre.text = "Nombre: $name"

                        // Imagen
                        var sprites = jsonObject.getJSONObject("sprites")
                        var imageUrl = sprites.getString("front_default")
                        Glide.with(this).load(imageUrl).into(ivPokemon)

                        // Tipos
                        var typesArray = jsonObject.getJSONArray("types")
                        var tipos = mutableListOf<String>()
                        for (i in 0 until typesArray.length()) {
                            var typeObj = typesArray.getJSONObject(i).getJSONObject("type")
                            tipos.add(typeObj.getString("name"))
                        }
                        tvTipo.text = "Tipo: ${tipos.joinToString(", ")}"

                        // Habilidades
                        var abilitiesArray = jsonObject.getJSONArray("abilities")
                        var habilidades = mutableListOf<String>()
                        for (i in 0 until abilitiesArray.length()) {
                            var abilityObj = abilitiesArray.getJSONObject(i).getJSONObject("ability")
                            habilidades.add(abilityObj.getString("name"))
                        }
                        tvHabilidades.text = "Habilidades:  \n${habilidades.joinToString(", ")}"

                    } catch (e: Exception) {
                        Toast.makeText(this, "Error al procesar datos", Toast.LENGTH_SHORT).show()
                    }
                },
                { error ->
                    Toast.makeText(this@MainActivity, "POKEMON NO ENCONTRADO", Toast.LENGTH_SHORT).show()
                }
            )

            queue.add(stringRequest)
        }
    }
}
